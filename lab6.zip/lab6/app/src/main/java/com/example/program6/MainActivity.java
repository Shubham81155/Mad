package com.example.program6;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editName, editEmail;
    RadioGroup genderGroup;
    Spinner spinnerHobbies;
    Button btnSubmit;

    String[] hobbies = {"Reading", "Traveling", "Gaming", "Cooking", "Drawing"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize Views
        editName = findViewById(R.id.editName);
        editEmail = findViewById(R.id.editEmail);
        genderGroup = findViewById(R.id.genderGroup);
        spinnerHobbies = findViewById(R.id.spinnerHobbies);
        btnSubmit = findViewById(R.id.btnSubmit);

        // Set spinner values
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, hobbies);
        spinnerHobbies.setAdapter(adapter);

        // Handle button click
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = editName.getText().toString().trim();
                String email = editEmail.getText().toString().trim();

                // Get gender
                int selectedId = genderGroup.getCheckedRadioButtonId();
                RadioButton selectedRadioButton = findViewById(selectedId);
                String gender = (selectedRadioButton != null) ? selectedRadioButton.getText().toString() : "Not selected";

                // Get selected hobby
                String hobby = spinnerHobbies.getSelectedItem().toString();

                // Show data in Toast
                String message = "Name: " + name + "\nEmail: " + email + "\nGender: " + gender + "\nHobby: " + hobby;
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}
