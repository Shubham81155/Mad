package com.example.lab6;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btnsave,btnnext;
    EditText etusername,etpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        btnsave = (Button) findViewById(R.id.btnsave);
        btnnext =(Button)findViewById(R.id.btnnext);
        etusername =(EditText)findViewById(R.id.etusername);
        etpassword =(EditText)findViewById(R.id.etpassword);
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                @SuppressLint("CommitPrefEdits") Editor editor = (Editor) (Editor) sharedPreferences.edit();
                editor.putString("username", etusername.getText().toString());
                editor.putString("password", etpassword.getText().toString());
                editor.apply();
                Toast.makeText(MainActivity.this, "Data saved", Toast.LENGTH_SHORT).show();
            }
        });
        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });
    }

    private static class Editor {
        public void putString(String username, String string) {
        }

        public void apply() {
        }
    }
}